# Movie-Review-website
Built using HTML, CSS, JavaScript, PHP and MySQL. It is an online database of information related to films and television programs. allows users to login, review and read a small summary of the film.
